using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookingWeb.Models
{
    public class Booking
    {
        public int Id { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }

        [Required]
        public string BookedBy { get; set; } = null!;  // Non-nullable with default

        [Required]
        public string Purpose { get; set; } = null!;  // Required

        // Foreign Key relationship to Resource
        public int ResourceId { get; set; }

        [ForeignKey("ResourceId")]
        public Resource? Resource { get; set; }  // Nullable to avoid null reference exceptions
    }
}

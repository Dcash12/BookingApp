using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookingWeb.Models;

namespace BookingWeb.Controllers
{
    public class ResourcesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ResourcesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Resources
        public async Task<IActionResult> Index()
        {
            try
            {
                return View(await _context.Resources.ToListAsync());
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error loading resources: {ex.Message}";
                return View(new List<Resource>());
            }
        }

        // GET: Resources/Details/5
        public async Task<IActionResult> Details(int? id)
{
    if (id == null) return NotFound();

    try
    {
        var resource = await _context.Resources
            .Include(r => r.Bookings)
            .FirstOrDefaultAsync(r => r.Id == id);

        if (resource == null) return NotFound();

        // Filter upcoming bookings (EndTime in future)
        var upcomingBookings = resource.Bookings
            .Where(b => b.EndTime >= DateTime.UtcNow)
            .OrderBy(b => b.StartTime)
            .ToList();

        ViewBag.UpcomingBookings = upcomingBookings;

        return View(resource);
    }
    catch (Exception ex)
    {
        ViewBag.Error = $"Error loading resource details: {ex.Message}";
        return View(new Resource());  // Pass empty model to avoid null references
    }
}


        // GET: Resources/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Resources/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name,Description,Location,Capacity,IsAvailable")] Resource resource)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(resource);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error creating resource: {ex.Message}");
                }
            }
            return View(resource);
        }

        // GET: Resources/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            try
            {
                var resource = await _context.Resources.FindAsync(id);
                if (resource == null) return NotFound();

                return View(resource);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error loading resource for edit: {ex.Message}";
                return View();
            }
        }

        // POST: Resources/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description,Location,Capacity,IsAvailable")] Resource resource)
        {
            if (id != resource.Id) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(resource);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ResourceExists(resource.Id))
                        return NotFound();

                    ModelState.AddModelError("", "The record was modified or deleted by another user.");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error updating resource: {ex.Message}");
                }
            }
            return View(resource);
        }

        // GET: Resources/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            try
            {
                var resource = await _context.Resources.FirstOrDefaultAsync(m => m.Id == id);
                if (resource == null) return NotFound();

                return View(resource);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error loading resource for delete: {ex.Message}";
                return View();
            }
        }

        // POST: Resources/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var resource = await _context.Resources.FindAsync(id);
                if (resource == null) return NotFound();

                _context.Resources.Remove(resource);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error deleting resource: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        private bool ResourceExists(int id)
        {
            return _context.Resources.Any(e => e.Id == id);
        }
    }
}



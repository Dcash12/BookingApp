using Microsoft.EntityFrameworkCore;
using BookingWeb.Models;

public class ApplicationDbContext : DbContext
{
    public DbSet<Resource> Resources { get; set; }
    public DbSet<Booking> Bookings { get; set; }

    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // One-to-many Resource -> Bookings
        builder.Entity<Booking>()
               .HasOne(b => b.Resource)
               .WithMany(r => r.Bookings)
               .HasForeignKey(b => b.ResourceId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}